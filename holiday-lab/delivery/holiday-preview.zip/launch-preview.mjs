import fs from 'node:fs';import path from 'node:path';import net from 'node:net';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));const args=process.argv.slice(2);const portArg=args.find(a=>a.startsWith('--port='));const port=portArg?Number(portArg.slice(7)):8801;
if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Invalid local port');
const url='http://127.0.0.1:'+port+'/';
const occupied=await new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port});s.once('connect',()=>{s.destroy();resolve(true);});s.once('error',()=>resolve(false));});
if(occupied){console.error('Port '+port+' is already in use. Close the previous preview first, or run Start-Preview.cmd --port=8802.');process.exitCode=1;}else{
 const logfile=fs.openSync(path.join(root,'preview-server.log'),'a');const child=spawn(process.execPath,[path.join(root,'serve-review.mjs'),path.join(root,'site'),String(port)],{cwd:root,windowsHide:true,detached:true,stdio:['ignore',logfile,logfile]});child.unref();fs.closeSync(logfile);
 let ready=false;for(let i=0;i<40;i++){try{const response=await fetch(url);if(response.ok&&(await response.text()).includes('<html')){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,150));}
 if(!ready){try{process.kill(child.pid);}catch{}throw Error('Preview server did not become ready; see preview-server.log');}
 fs.writeFileSync(path.join(root,'preview-server.json'),JSON.stringify({pid:child.pid,port,url},null,2));console.log('READY '+url+' PID='+child.pid);
 if(!args.includes('--no-browser')){const opener=spawn('cmd.exe',['/d','/c','start','',url],{windowsHide:true,detached:true,stdio:'ignore'});opener.unref();}
}
