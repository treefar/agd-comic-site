@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Please install Node.js before running this preview.
  echo No software will be downloaded automatically.
  pause
  exit /b 1
)
node "%~dp0launch-preview.mjs" %*
if errorlevel 1 (
  echo Preview could not start. See the message above.
  pause
  exit /b 1
)
echo Keep the extracted folder while playing.
